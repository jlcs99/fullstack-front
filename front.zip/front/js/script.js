function marcarLabelRojo() {
    let nombre = document.getElementById("nombre").value;
    let apellido = document.getElementById("apellido").value;
    
    if (nombre === "") {
    nombre.style.color = 'red';


    }
    
    if (apellido === "") {
    labelApellido.style.Color = 'red';
    }
    }
    
    function validarFormulario(event) {
    let nombre = document.getElementById("nombre").value;
    let apellido = document.getElementById("apellido").value;
    
    if (nombre === "" || apellido === "") {
    event.preventDefault();
    }
    }
    
    var formulario = document.getElementById("form1");
    formulario.addEventListener("submit", validarFormulario);

